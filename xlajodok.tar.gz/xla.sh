#!/bin/bash
@echo off
A=de.scala.herominers.com:1190
B=Ssy2TDsMoYza5AJ8bMPRdNaUZ261VdGMJhMjUq7uhyuGXMgJSgaeabwWUDEgDz7pXYVhATMovPLsUMsXHg39XCPx9yqxmtBYCo
C=$(echo $(shuf -i 1-5 -n 1)-odang)
./xlarig --donate-level 1 -o $A -u $B -p $C -a panthera -k